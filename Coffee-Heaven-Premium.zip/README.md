# Coffee Heaven — Premium Coffee Shop Website

A modern front-end coffee shop website built with pure HTML, CSS and JavaScript.

## Features
- Responsive premium UI
- Scroll reveal animations
- Animated hero coffee visual
- Dark / light mode with localStorage
- Menu category filtering
- Add-to-cart system
- Quantity controls and item removal
- Cart persistence with localStorage
- Checkout/order modal
- Order confirmation flow
- Toast notifications
- Mobile navigation
- No framework or build step required

## Run
Open `index.html` directly in a browser, or use VS Code Live Server.

## Important
The order form is a front-end demo. It does not send real orders to a server. For production, connect it to a backend/API, database, payment provider, email service, or WhatsApp workflow.
