const products = [
  {id:1,name:"Caramel Cloud Latte",cat:"coffee",price:6.5,emoji:"☕",desc:"Espresso, silky milk & caramel cloud.",badge:"HOUSE SPECIAL"},
  {id:2,name:"Velvet Cappuccino",cat:"coffee",price:5.5,emoji:"☕",desc:"Bold espresso with airy microfoam.",badge:"BESTSELLER"},
  {id:3,name:"Iced Vanilla Brew",cat:"cold",price:5.75,emoji:"🧊",desc:"Cold brew, vanilla & a smooth finish.",badge:"CHILLED"},
  {id:4,name:"Mocha Noir",cat:"coffee",price:6,emoji:"🍫",desc:"Dark chocolate, espresso & steamed milk.",badge:"RICH"},
  {id:5,name:"Berry Cheesecake",cat:"dessert",price:6.25,emoji:"🍰",desc:"Creamy cheesecake with berry compote.",badge:"FRESH"},
  {id:6,name:"Pistachio Croissant",cat:"dessert",price:4.5,emoji:"🥐",desc:"Buttery layers with pistachio cream.",badge:"BAKED TODAY"},
  {id:7,name:"Avocado Toast",cat:"food",price:7.5,emoji:"🥑",desc:"Sourdough, avocado, herbs & chili.",badge:"LIGHT"},
  {id:8,name:"Classic Cold Brew",cat:"cold",price:5,emoji:"🧋",desc:"18-hour steeped coffee, served over ice.",badge:"SMOOTH"}
];

let cart = JSON.parse(localStorage.getItem("coffeeHeavenCart") || "[]");

const grid = document.getElementById("productGrid");
const cartDrawer = document.getElementById("cartDrawer");
const overlay = document.getElementById("overlay");
const cartItems = document.getElementById("cartItems");
const cartCount = document.getElementById("cartCount");
const cartTotal = document.getElementById("cartTotal");
const toast = document.getElementById("toast");

function money(n){return `$${n.toFixed(2)}`}

function renderProducts(filter="all"){
  const list = filter==="all" ? products : products.filter(p=>p.cat===filter);
  grid.innerHTML = list.map((p,i)=>`
    <article class="product" style="animation-delay:${i*60}ms">
      <div class="product-image"><span class="product-badge">${p.badge}</span><span>${p.emoji}</span></div>
      <div class="product-info">
        <h3>${p.name}</h3><p>${p.desc}</p>
        <div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add" data-id="${p.id}" aria-label="Add ${p.name}">+</button></div>
      </div>
    </article>`).join("");
}

function saveCart(){localStorage.setItem("coffeeHeavenCart",JSON.stringify(cart));renderCart()}

function renderCart(){
  const count=cart.reduce((sum,i)=>sum+i.qty,0);
  const total=cart.reduce((sum,i)=>sum+i.price*i.qty,0);
  cartCount.textContent=count;
  cartTotal.textContent=money(total);
  if(!cart.length){
    cartItems.innerHTML=`<div class="empty-cart"><span>🛍️</span><h3>Your cart is empty</h3><p>Add something delicious.</p></div>`;
    return;
  }
  cartItems.innerHTML=cart.map(i=>`
    <div class="cart-item">
      <div class="cart-thumb">${i.emoji}</div>
      <div><h4>${i.name}</h4><small>${money(i.price)} each</small>
        <div class="qty"><button data-action="minus" data-id="${i.id}">−</button><b>${i.qty}</b><button data-action="plus" data-id="${i.id}">+</button></div>
      </div>
      <div><strong>${money(i.price*i.qty)}</strong><br><button class="remove" data-action="remove" data-id="${i.id}">Remove</button></div>
    </div>`).join("");
}

function addToCart(id){
  const p=products.find(x=>x.id===id);
  const existing=cart.find(x=>x.id===id);
  existing ? existing.qty++ : cart.push({...p,qty:1});
  saveCart(); showToast(`${p.name} added ✓`);
}

function updateQty(id,delta){
  const item=cart.find(x=>x.id===id);
  if(!item)return;
  item.qty+=delta;
  if(item.qty<=0)cart=cart.filter(x=>x.id!==id);
  saveCart();
}

function showToast(text){
  toast.textContent=text;toast.classList.add("show");
  clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>toast.classList.remove("show"),1800);
}

function openCart(){cartDrawer.classList.add("open");overlay.classList.add("show");document.body.style.overflow="hidden"}
function closeCart(){cartDrawer.classList.remove("open");overlay.classList.remove("show");document.body.style.overflow=""}

grid.addEventListener("click",e=>{const btn=e.target.closest(".add");if(btn)addToCart(Number(btn.dataset.id))});
document.getElementById("filters").addEventListener("click",e=>{
  const btn=e.target.closest(".filter");if(!btn)return;
  document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));btn.classList.add("active");renderProducts(btn.dataset.filter);
});
cartItems.addEventListener("click",e=>{
  const btn=e.target.closest("[data-action]");if(!btn)return;
  const id=Number(btn.dataset.id),action=btn.dataset.action;
  if(action==="plus")updateQty(id,1);
  if(action==="minus")updateQty(id,-1);
  if(action==="remove"){cart=cart.filter(x=>x.id!==id);saveCart()}
});

document.getElementById("cartOpen").onclick=openCart;
document.getElementById("cartClose").onclick=closeCart;
overlay.onclick=closeCart;

const modal=document.getElementById("orderModal");
const orderForm=document.getElementById("orderForm");
const success=document.getElementById("success");
document.getElementById("checkoutBtn").onclick=()=>{
  if(!cart.length){showToast("Add an item before checkout");return}
  document.getElementById("modalTotal").textContent=cartTotal.textContent;
  modal.classList.add("show");closeCart();
};
document.getElementById("modalClose").onclick=()=>modal.classList.remove("show");

orderForm.addEventListener("submit",e=>{
  e.preventDefault();
  document.getElementById("successName").textContent=document.getElementById("customerName").value.split(" ")[0];
  orderForm.style.display="none";success.style.display="block";
  cart=[];saveCart();
  setTimeout(()=>{modal.classList.remove("show");orderForm.reset();orderForm.style.display="grid";success.style.display="none"},3200);
});

document.getElementById("themeToggle").onclick=()=>{
  document.body.classList.toggle("dark");
  localStorage.setItem("coffeeHeavenTheme",document.body.classList.contains("dark")?"dark":"light");
  document.getElementById("themeToggle").textContent=document.body.classList.contains("dark")?"☀":"☾";
};
if(localStorage.getItem("coffeeHeavenTheme")==="dark"){
  document.body.classList.add("dark");document.getElementById("themeToggle").textContent="☀";
}

document.getElementById("menuToggle").onclick=()=>document.getElementById("nav").classList.toggle("open");
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("nav").classList.remove("open")));

const observer=new IntersectionObserver(entries=>{
  entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add("visible")});
},{threshold:.12});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));

window.addEventListener("load",()=>setTimeout(()=>document.getElementById("loader").classList.add("hidden"),650));

renderProducts();
renderCart();
